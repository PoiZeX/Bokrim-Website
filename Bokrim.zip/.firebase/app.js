/*
import { initializeApp } from 'firebase/app'
import {
    getFirestore, collection
} from 'firebase/firestore'



initializeApp(firebaseConfig)

const db = getFirestore()


const colRef = collection(db, 'users')
console.log(firebase);

*/
document.addEventListener("DOMContentLoaded", event => {
    const app = firebase.app();
});

function googleLogin() {
    const provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider)
        .then(result => {
            const user = result.user;
            //document.write(,Hello ${user.displayName}');
            console.log(user)

        })
        .catch(console.log)
}
